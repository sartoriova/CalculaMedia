package DDM.aula2023_03_28;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.time.format.TextStyle;

public class MainActivity extends AppCompatActivity {

    private EditText txtNome;
    private EditText txtEmail;
    private EditText txtNota1;
    private EditText txtNota2;

    private TextView tvMedia;

    private Button btnCalcular;
    private Button btnExibir;
    private Button btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNome = findViewById(R.id.txtNome);
        txtEmail = findViewById(R.id.txtEmail);
        txtNota1 = findViewById(R.id.txtNota1);
        txtNota2 = findViewById(R.id.txtNota2);

        tvMedia = findViewById(R.id.tvMedia);

        btnCalcular = findViewById(R.id.btnCalcular);
        btnExibir = findViewById(R.id.btnExibir);
        btnSair = findViewById(R.id.btnSair);

        btnSair.setOnClickListener(new EscutadorBtnSair());
        btnCalcular.setOnClickListener(new EscutadorBtnCalcular());
        btnExibir.setOnClickListener(new EscutadorBtnExibir());
    }

    class EscutadorBtnSair implements View.OnClickListener{

        @Override
        public void onClick(View view) {
            System.exit(0);
        }
    }

    class EscutadorBtnCalcular implements View.OnClickListener{

        @Override
        public void onClick(View view) {
            double nota1, nota2, media;

            nota1 = Double.parseDouble(txtNota1.getText().toString());
            nota2 = Double.parseDouble(txtNota2.getText().toString());

            media = (nota1+nota2)/2;

            tvMedia.setText(Double.toString(media));
        }
    }

    class EscutadorBtnExibir implements View.OnClickListener{

        @Override
        public void onClick(View view) {
            String msg = "";

            msg = msg + "Nome: "+txtNome.getText() + "\n";
            msg = msg + "E-mail: "+txtEmail.getText() + "\n";
            msg = msg + "Notas: " + txtNota1.getText() + " e " + txtNota2.getText();

            Toast.makeText( getApplicationContext(), msg , Toast.LENGTH_LONG ).show();
        }
    }
}